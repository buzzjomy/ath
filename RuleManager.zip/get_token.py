from seleniumwire import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import env

service = Service(executable_path=r"C:\Workitems\code\Story\RuleManager\chromedriver-win64\chromedriver.exe")
options = webdriver.ChromeOptions()
user_data_dir = r'C:\Users\E406692\AppData\Local\Google\Chrome\User Data'
driver = webdriver.Chrome(service=service, options=options)


def get_token():
    driver.get("https://rule-manager.workflownextgen.dev.atheneawsnp.com/")
    # set implicit wait time 
    driver.implicitly_wait(10) # seconds 

    username = driver.find_element(By.XPATH, '//input[@id="input44"]').send_keys(env.username)
    driver.find_element(By.XPATH, '//input[@value="Next"]').click()
    password = driver.find_element(By.XPATH, '//input[@id="input72"]').send_keys(env.password)
    driver.find_element(By.XPATH, '//input[@value="Verify"]').click()
    driver.find_element(By.XPATH, "//a[@aria-label='Select to get a push notification to the Okta Verify app.']").click()

    WebDriverWait(driver, 60).until(EC.presence_of_element_located((By.XPATH, '//button[@id="home_btn"]')))

    for request in driver.requests:
        # input(type(request.headers))
        if 'cookie' in request.headers:
            if 'AWSALBAuthNonce' in request.headers['cookie']:
                # print(f"Request Headers: {request.headers}")
                token = request.headers['cookie']
                print(token)
                driver.close()
                return token

    

