from cryptography.fernet import Fernet

# Generate a key (keep this secret and store it securely)
key = Fernet.generate_key()
key = b'z_D-fCUhklGT8a_2I2-VDCnGC8ylwZAdhytMwXxuSJ8='
cipher_suite = Fernet(key)
print(key)

# Password to encrypt
pey = "qAwzsx@3456"

# Encrypt the password (encode to bytes first)
ciphered_password = cipher_suite.encrypt(pey.encode())
print('ciphered_password', ciphered_password)
print("Encrypted password:", ciphered_password.decode())

def return_pwd():
    f = Fernet(key)
    decrypted_password = f.decrypt( ciphered_password.decode().encode())
    return decrypted_password.decode()
# # key = load_key()
# f = Fernet(key)

# decrypted_password = f.decrypt( ciphered_password.decode().encode())
# (decrypted_password.decode())