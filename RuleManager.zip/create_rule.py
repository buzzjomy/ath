import requests
import json

url = "https://rule-manager.workflownextgen.dev.atheneawsnp.com/data/rules"

payload = json.dumps({
  "rule_name": "WR_TA1_API",
  "rule_type": "WORKFLOW_ROUTING",
  "category": [
    "ADDRESS"
  ],
  "transaction_type": [
    "CDM#NEWBUSINESS"
  ],
  "status": "ACTIVE",
  "description": "WR_TA1 Desc",
  "undefined": "01JSKM1ZT0DKQ56QPG5D6VTQQ7",
  "notes": "WR_TA1 Notes",
  "evaluate": {
    "business_rule_id": "01JSKM1ZT0DKQ56QPG5D6VTQQ7"
  },
  "actions": {
    "on_true": [
      {
        "route_to_rule": {
          "rule_id": "end"
        }
      }
    ],
    "on_false": [
      {
        "append_data_via_api": {
          "api_name": "ALIP/address_validation"
        }
      },
      {
        "route_to_rule": {
          "rule_id": "end"
        }
      }
    ],
    "always": [
      {
        "log_entry": {
          "message": "WR_TA1 Test Log message"
        }
      }
    ]
  },
  "pk": "01JSKMMHQE9QVEDJXG3W57G57C",
  "sk": "RELEASE#WORKFLOWRULEVALIDATION",
  "gsi1pk": "RELEASE#WORKFLOWRULEVALIDATION"
})
headers = {
  'host': 'rule-manager.workflownextgen.dev.atheneawsnp.com',
  'accept': '*/*',
  'cookie': 'ath_active_role=QWRtaW4=; RuleManagerAuthSessionCookie-0=ddnKWtARIB9gyzWVhOas3u9OsCGcX9cTH0nU/KUkbPu2FqthR2GUtCWG1zRV/V9YKLEVPf6zMJNAZin/WXlNUO4nQCh9EHfwCPO4r5pS2HmIm95zycyrYTyzBNe0LiHLPV9YcC8EXT4HFh8dTJSQ393pBtzXJErK77su/uBK2D1gd0oSMFUhU3sBG/ZUgccQY3ZcpVBjbDVs+sBN7OdLPjzS5Ed1MTMoxJWXONNTS5zqPSbV0jHY27aHUd0JzHdpPv3WA6dCtRW8WbVL3S7rHNTTSZD8tz9vw/v8k216mQ10yma9wUFSXdSKzKFAcdv4JAAB2My5XjrJLuRVgxTodruGW+XuMp6PPptq5cNo9AQvOvlhMDi2iTYylW1LV/AT8VRGE/JGo1JdYsmqVL4GRWiLi0phrH8BwloGf+pXg/QfBBquGr+vUkXfKP1Jo0eayJ46JEOlpUZJc9TchqezIoZHD9PAb0zzkNFvV5nlCHX1Sjq3Hq5ZaFMM0dut6lAtohY5jnP9kQxnyfXsBU8iR6wTE1xrO9GqY5H+wmW81zsiyYRpIptdPYBMwQWTWomGZjjlLgwQil9dlcsY4V53i1Ggml2kY0VxZaMlCn4rs8VUQWbluJl8AEWRD+5B8BJSVaLmt/4KBxAbwiC1eqW3hjuaKPucqZrCPMREgJnxKZS5WnblsdW7NAhYuNgr/tLBQvIKK9jfNt56/ec87ImRCM59iLbF8zm/AqaeIOJDtoQErccoGuU6JBFipkocvOSsZCAEzLIdzqBz4d77MMu8eAs0EQWn3EgId4zMdS+tJ+f/RQgUx2dc2pK9Gcix9+Y4R1s2FJVtprpsj3HMj4l8mGXJ5ObFAchYnNhLX9ILOmmxz5IGEnyEi3HixxlyDt+qx6zcS2W6FI9IJ+QRSrXdpea/oeNbVy1c/TsQINWGpeeVps1KgowQ7292lh3IocVRHdD7/1aYfX+dyTPkHrEJBEJJJCcbXjooXGUhs5ljcNa0mVAoFxWMl2dwziqimy/nJkys6B2T0rr/JF6Hzf2R1txSRKxB56vjpNUAMQ7atYT7L71/4SUE3CRcKETjaYwbKPkgVpLrpCBXT/dY7AlW0++Y7dVjv1dLGpHVk/13kL4MEmcSp9mubiSb0Ij0DQ6QtYa8RDfcJfHHTBBvGD7XM1sHIPq9FQf5q0LlkgoQ2IqBniiOp2ikT4Y6cSB+TvTK9TcuoWG010xHZJlGOKi1Ho4GU3gMDHkWqUaaZXSwxljrWpY9KdisP7sfGJCr4KdqaFRCt9T7f32uF6sfADXyiniTq6TLmEI+PhwROtY06FEl0T0ioWy6nynBl+SVhXb45gcLJXAKASNaYAhnCmUQHZmLIAAxbrq6LNLRHCFf5meQp0OIL4zeaJT6pqvOLAhGoSBow03+P9JY5BNepBaF9hhWiA3LN6TLthQ2d+RXWyNrUWRS0x13cYeGZA03u9bozf7MM6o6AXo4bZIhpYj1kxfffQRhOU1IfQwC9axg+7/0Aq9aOWxtDDdbd/Og0ZuEKUeE5K8YJdXjxRKVXq6WnKe/h8EIDxXy5PSVuJ7yLigZtfBwrZJ1HsOgD61ibNTZ1MWjp85ERzH2kIY7D0cas1/fGxCeGySDIpA01PB7z/4mvUx115l/p+zpUXaDIy/5nQc7VItEs5+0O2RoxcRvk845k/YIy8HopgFIuesicKolV0z7BDjul9/mxg5XKAGm+bfVDd9rYFUceCaPmdL8XFB/vhRII93UFWAg58SIjogvsUvECghSHcMD3KEhjtIk/iAjh9/GQBdhy18OoaqibvEUkNrc3WtH1MyAXt+c51uz74kO0zINsklX/vgs9KUeCLmrBeHTQ9uKFSV2w+JmO/bRpi/AT0MDd1fYlq1Wnt7cFrIzdjiGgCmawsNPMM86ObrCumkDWM28w8XowmN8vm9Kzyd7tzGaC7BqcZM6SmyYjs5fuuY4Mnprm+dSuGeXQOun3Xtp/lAh7XNbnUuQnttOWX0NCZhJ3IOkJe6/5cRFTSg3UbT6IeY=',
  'origin': 'https://rule-manager.workflownextgen.dev.atheneawsnp.com',
  'referer': 'https://rule-manager.workflownextgen.dev.atheneawsnp.com/',
  'sec-ch-ua': '"Google Chrome";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
  'connection': 'keep-alive',
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
  'content-type': 'application/json',
  'content-length': '635',
  'sec-fetch-dest': 'empty',
  'sec-fetch-mode': 'cors',
  'sec-fetch-site': 'same-origin',
  'accept-encoding': 'gzip, deflate, br, zstd',
  'accept-language': 'en-US,en;q=0.9',
  'x-postman-captr': '97832',
  'sec-ch-ua-mobile': '?0',
  'x-requested-with': 'XMLHttpRequest',
  'sec-ch-ua-platform': '"Windows"'
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)
