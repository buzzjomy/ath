import crypt

username='E406692@atheneusa.com'
password=crypt.return_pwd()